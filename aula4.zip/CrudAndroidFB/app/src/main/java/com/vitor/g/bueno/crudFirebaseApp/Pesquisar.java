package com.vitor.g.bueno.crudFirebaseApp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.vitor.g.bueno.crudFirebaseApp.Modelo.Pessoa;

import java.util.ArrayList;
import java.util.List;

public class Pesquisar extends AppCompatActivity {

    private EditText edtPesquisa;
    private ListView lstPesquisa;

    //Objetos para Firebase
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    //Carregar os dados na Lista
    private List<Pessoa> listPessoa = new ArrayList<Pessoa>();
    private ArrayAdapter<Pessoa> arrayAdapterPessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pequisar);

        edtPesquisa = (EditText) findViewById(R.id.edtPesquisa);
        lstPesquisa = (ListView) findViewById(R.id.lstPesquisa);

        inicializarFirebase();
        fazerPesquisa();
    }


    private void fazerPesquisa(){
        edtPesquisa.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String busca = edtPesquisa.getText().toString().trim();
                pesquisarNome(busca);
            }
        });
    }

    private void inicializarFirebase(){
        FirebaseApp.initializeApp(Pesquisar.this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        //Para a Lista
        databaseReference = firebaseDatabase.getReference();
    }

    private void pesquisarNome(String busca){
        Query consulta;
        if (busca.equals("")){
            consulta = databaseReference.child("Pessoa").orderByChild("nome");
        }
        else{
            consulta = databaseReference.child("Pessoa").orderByChild("nome").startAt(busca).endAt(busca+"\uf8ff");
        }
        listPessoa.clear();

        consulta.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot objSnapshot:dataSnapshot.getChildren()){
                    Pessoa p = objSnapshot.getValue(Pessoa.class);
                    listPessoa.add(p);
                }

                arrayAdapterPessoa = new ArrayAdapter<Pessoa>
                (Pesquisar.this, android.R.layout.simple_list_item_1, listPessoa);
                lstPesquisa.setAdapter(arrayAdapterPessoa);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    protected void onResume(){
        super.onResume();
        pesquisarNome("");
    }
}

