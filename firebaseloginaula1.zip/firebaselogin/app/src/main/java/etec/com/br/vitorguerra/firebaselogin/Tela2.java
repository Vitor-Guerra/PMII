package etec.com.br.vitorguerra.firebaselogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Tela2 extends AppCompatActivity {
    Button btLogoff;
    private FirebaseAuth usuario = FirebaseAuth.getInstance();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        btLogoff = findViewById(R.id.btnLogoff);
        btLogoff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Faz o LOGOFF
                usuario.signOut();
                //Finaliza a Activity
                finish();
                //Mensagem de começo
                Toast.makeText(Tela2.this, "Logout Efetuado com Sucesso!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
