package etec.com.br.vitorguerra.firebaselogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    EditText edEmail, edSenha;
    Button btCadastra, btLoga;
    String email, senha;

    private FirebaseAuth usuario = FirebaseAuth.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edEmail = findViewById(R.id.edtMail);
        edSenha = findViewById(R.id.edtSenha);
        btCadastra = findViewById(R.id.btnCadastra);
        btLoga = findViewById(R.id.btnLoga);

        btCadastra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                email = edEmail.getText().toString();
                senha = edSenha.getText().toString();
                if(email.isEmpty() || senha.isEmpty()){
                    Toast.makeText(MainActivity.this, "Nenhum dos campos pode ficar em branco!", Toast.LENGTH_SHORT).show();
                }else if (senha.length()<6){
                    Toast.makeText(MainActivity.this, "O campo senha não pode ter menos que 6 digitos!", Toast.LENGTH_SHORT).show();
                }else {
                    usuario.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(MainActivity.this, "Usuário Cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                                usuario.signOut();
                                edEmail.setText("");
                                edSenha.setText("");

                            }else{
                                Toast.makeText(MainActivity.this, "Erro ao Cadastrar! :/", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });
    }
}
