package com.example.firebaseimagem.vitor.g.bueno;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

public class MostrarImagens extends AppCompatActivity {
    private String[]urlImagens = new String[]{
            "https://firebasestorage.googleapis.com/v0/b/fir-uploadvitor.appspot.com/o/imagens%2Fshrek1.jpg?alt=media&token=fb668ba4-0885-4b4a-a9a0-f1da6fa29a55",
            "https://firebasestorage.googleapis.com/v0/b/fir-uploadvitor.appspot.com/o/imagens%2Fshrek2.jpg?alt=media&token=83fdadbe-8ae1-47c4-b8fb-2d88b6b5ef50",
            "https://firebasestorage.googleapis.com/v0/b/fir-uploadvitor.appspot.com/o/imagens%2Fshrek3.jpg?alt=media&token=54ad9191-7ebe-492a-a634-9ed17d4b6a62",
            "https://firebasestorage.googleapis.com/v0/b/fir-uploadvitor.appspot.com/o/imagens%2Fshrek4.jpg?alt=media&token=96ca046e-a976-44ee-9dbf-ba618297d633"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mostrar_imagens);
        ViewPager viewPager = findViewById(R.id.view_pager);
        ViewPageAdapter adapter = new ViewPageAdapter(this, urlImagens);
        viewPager.setAdapter(adapter);
    }
}
