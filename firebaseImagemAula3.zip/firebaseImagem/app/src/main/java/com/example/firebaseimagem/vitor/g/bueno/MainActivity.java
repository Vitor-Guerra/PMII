package com.example.firebaseimagem.vitor.g.bueno;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    ImageView imgFoto;
    Button btnCarrega, btnVer;

    private final int GALERIA_IMAGENS = 1;
    private final int PERMISSAO_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgFoto = findViewById(R.id.imgFoto);
       // imgFoto.setImageResource(R.drawable.padrao);
//JANELA DE PERMISSÃO
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.READ_EXTERNAL_STORAGE)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new
                                String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        PERMISSAO_REQUEST);
            }
        }

        btnVer = findViewById(R.id.btnVer);

        btnVer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MostrarImagens.class);
                startActivity(intent);
            }
        });
        btnCarrega = findViewById(R.id.btnCarrega);
        btnCarrega.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
        //CASO A IMAGEM NÃO ESTEJA CARREGADA NA IMAGEVIEW
                Intent intent = new Intent(Intent.ACTION_PICK,
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent,GALERIA_IMAGENS);
            }
        });
    }
    //ABRIR A GALERIA DE IMAGEM E SELECIONAR A IMAGEM
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode == RESULT_OK && requestCode == GALERIA_IMAGENS) {
            Uri selectedImage = data.getData();
            String[] filePath = {MediaStore.Images.Media.DATA };
            Cursor c = getContentResolver().query(selectedImage,
                    filePath, null, null, null);
            c.moveToFirst();
            int columnIndex = c.getColumnIndex(filePath[0]);
            String picturePath = c.getString(columnIndex);
            c.close();
            Bitmap thumbnail = (BitmapFactory.decodeFile(picturePath));
            imgFoto.setImageBitmap(thumbnail);
//CONFIGURA A IMAGEM PARA SER SALVA EM MEMÓRIA
            imgFoto.setDrawingCacheEnabled(true);
            imgFoto.buildDrawingCache();
//RECUPERA O BITMAP DA IMAGEM A SER CARREGADA
            Bitmap bitmap = imgFoto.getDrawingCache();
//COMPRIMIR A IMAGEM EM FORMATO VÁLIDO
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 75,
                    baos);//(THANOS)
//CONVERTER O baos EM PIXELS PARA ENVIAR (DR.HULK)
            byte[] dadosImagem = baos.toByteArray();
//ACESSAR O FIREBASE
            StorageReference storageReference =
                    FirebaseStorage.getInstance()
                            .getReference();
//CRIAR A PASTA PARA AS IMAGENS
            StorageReference imagens
                    =storageReference.child("imagens");
//GERAR NOME ALEATÓRIO PARA A IMAGEM
            String nomeImagem = UUID.randomUUID().toString();
//ASSOCIAR NOME E ENXTENSÃO
            StorageReference imagemRef =
                    imagens.child(nomeImagem+".jpeg");
//CONTROLAR O UPLOAD
            UploadTask uploadTask = imagemRef.putBytes(dadosImagem);
            uploadTask.addOnFailureListener(MainActivity.this,
                    new OnFailureListener() {
                        @Override

                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(MainActivity.this,
                                    "\"Erro de Upload:\n" +
                                    "\"+e.getMessage().toString(),",
                                    Toast.LENGTH_SHORT).show();}
                    })//NÃO COLOCAR PONTO E VÍRGULA AQUI
                    .addOnSuccessListener(MainActivity.this,
                            new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override

                                public void onSuccess(UploadTask.TaskSnapshot

                                                              taskSnapshot) {
                                    Toast.makeText(MainActivity.this, "Upload feito",



                                            Toast.LENGTH_SHORT).show();
                                }
                            });//COLOCAR PONTO E VÍRGULA AQUI
        }
    }
    //RETORNO DA TELA DE PERMISSÃO
    @Override
    public void onRequestPermissionsResult
    (int requestCode,String permissions[], int[] grantResults) {
        if (requestCode == PERMISSAO_REQUEST) {
            if (grantResults.length > 0 && grantResults[0]
                    == PackageManager.PERMISSION_GRANTED) {
// A permissão foi concedida. Pode continuar
                btnCarrega.setEnabled(true);
            } else {
// A permissão foi negada.
// Precisa ver o que deve ser desabilitado
                btnCarrega.setEnabled(false);
//btnEnvia.setEnabled(false);
            }
            return;
        }
    }
}